module.exports = async (tp) => {
    class MonthlyNote {
        constructor() {
            this.thisMonthStart = moment().startOf("month");
            this.month = this.thisMonthStart.format("MMMM");
            this.year = this.thisMonthStart.format("YYYY");
            this.firstDay = this.thisMonthStart.clone();
            this.lastDay = this.thisMonthStart.clone().endOf("month");
            this.firstWeek = this.firstDay.isoWeek();
            this.lastWeek = this.lastDay.isoWeek();

            // Adjust for December/January transition
            if (this.firstWeek > this.lastWeek) {
                this.lastWeek = moment().endOf("year").isoWeek();
            }

            // Collect all weeks within the month
            this.weeks = [];
            for (let week = this.firstWeek; week <= this.lastWeek; week++) {
                this.weeks.push(week);
            }
        }

        get monthlyContent() {
            let content = `# 📅 ${this.month} ${this.year}\n\n`;
            content += `**Weeks ${this.weeks[0]} through ${
                this.weeks[this.weeks.length - 1]
            }**\n`;
            this.weeks.forEach((week) => {
                content += `- ![[Periodic Notes/Weekly/${this.year}/${this.year}-W${week}#🌟 Highlights]]\n`;
            });

            return content;
        }
    }

    const { monthlyContent } = new MonthlyNote();
    return { monthlyContent };
};
