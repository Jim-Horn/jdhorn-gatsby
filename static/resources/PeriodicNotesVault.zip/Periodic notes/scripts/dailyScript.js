const makeProgressBar = ({
    completedSymbol = "█",
    end,
    start,
    incompleteSymbol = "◽",
}) => {
    const remain = end - start;
    let content = `<span title="${start} of ${end}">${completedSymbol.repeat(
        start
    )}</span>`;
    content += `<span title="${remain} remain">${incompleteSymbol.repeat(
        remain
    )}</span>`;
    return content;
};

module.exports = async (tp) => {
    class DailyNote {
        constructor(tp) {
            this.tp = tp;
            this.fileDate = moment(tp.file.title);

            this.date = this.fileDate.format("DD");
            this.daysInMonth = this.fileDate.daysInMonth();
            this.monthLink = this.fileDate.format("YYYY-MM");
            this.monthNum = this.fileDate.format("MM");
            this.nextDay = this.fileDate.clone().add(1, "d");
            this.prevDay = this.fileDate.clone().subtract(1, "d");
            this.quarterLink = this.fileDate.format("YYYY-[Q]Q");
            this.startOfWeek = this.fileDate
                .clone()
                .startOf("week")
                .format("YYYY-MM-DD");
            this.today = this.fileDate.date();
            this.weekLink = this.fileDate.format("gggg-[W]WW");
            this.yearLink = this.fileDate.format("YYYY");
        }

        get metadata() {
            return {
                tags: `daily_note ${this.fileDate.format(
                    "dddd"
                )} ${this.fileDate.format("YYYYMMDD")}-full-date ${
                    this.weekLink
                } ${this.monthLink} ${this.quarterLink} ${
                    this.yearLink
                }-full-year`,
                weekday: this.fileDate.format("ddd"),
                created: moment().format("LLLL"),
            };
        }

        get navigation() {
            const notesFolder = "Periodic Notes";
            const prevMonthLink = this.prevDay.format("MM");
            const nextMonthLink = this.nextDay.format("MM");
            const prevYearLink = this.prevDay.format("YYYY");
            const nextYearLink = this.nextDay.format("YYYY");

            const prevDayLink = `[[${notesFolder}/Daily/${prevYearLink}/${prevMonthLink}/${this.prevDay.format(
                "YYYY-MM-DD"
            )}|Previous Day]]`;

            const nextDayLink = `[[${notesFolder}/Daily/${nextYearLink}/${nextMonthLink}/${this.nextDay.format(
                "YYYY-MM-DD"
            )}|Next Day]]`;

            const yearlyLink = `[[${notesFolder}/Yearly/${this.yearLink}|${this.yearLink}]]`;

            const quarterlyLink = `[[${notesFolder}/Quarterly/${
                this.yearLink
            }/${this.quarterLink}|${this.fileDate.format("[Q]Q")}]]`;

            const monthlyLink = `[[${notesFolder}/Monthly/${this.yearLink}/${
                this.monthLink
            }|${this.fileDate.format("MM")}]]`;

            const weeklyLink = `[[${notesFolder}/Weekly/${this.yearLink}/${
                this.weekLink
            }|${this.fileDate.format("[W]WW")}]]`;

            return `${prevDayLink} ⋮ ${yearlyLink} › ${quarterlyLink} › ${monthlyLink} › ${weeklyLink} ⋮ ${nextDayLink}`;
        }

        get progressBar() {
            return `\n\n${makeProgressBar({
                start: +this.monthNum,
                end: 12,
            })}\n${makeProgressBar({
                start: +this.date,
                end: +this.daysInMonth,
            })}\n(${this.date}/${this.daysInMonth})`;
        }
    }

    return ({ metadata, navigation, progressBar } = new DailyNote(tp));
};
