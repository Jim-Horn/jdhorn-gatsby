module.exports = async (tp) => {
    class WeeklyNote {
        constructor(tp) {
            this.tp = tp;
            this.highlightsBlock = `# 🌟 Highlights`;

            // Extract the week from the file title
            const fileTitle = this.tp.file.title; // e.g., "2024-W27"
            const weekFormat = "YYYY-[W]WW";

            // Parse the file title to determine the Monday of that week
            this.monday = moment(fileTitle, weekFormat).startOf("isoWeek");
            this.startDate = this.monday.format("YYYY-MM-DD"); // 2024-07-01
            this.friday = this.monday
                .clone()
                .add(4, "days")
                .format("YYYY-MM-DD");
        }

        get navigationLinks() {
            const fileTitle = this.tp.file.title; // e.g., "2024-W27"
            const weekFormat = "YYYY-[W]WW";

            const currentWeek = moment(fileTitle, weekFormat);
            const previousWeek = currentWeek
                .clone()
                .subtract(1, "week")
                .format(weekFormat);
            const nextWeek = currentWeek
                .clone()
                .add(1, "week")
                .format(weekFormat);

            const previousYear = currentWeek
                .clone()
                .subtract(1, "week")
                .format("YYYY");
            const nextYear = currentWeek.clone().add(1, "week").format("YYYY");
            const currentYear = currentWeek.format("YYYY");

            const previousWeekLink = `[[Periodic Notes/Weekly/${previousYear}/${previousWeek}|Previous week]]`;
            const nextWeekLink = `[[Periodic Notes/Weekly/${nextYear}/${nextWeek}|Next week]]`;

            const currentMonth = this.monday.format("MM");
            const monthlyLink = `[[Periodic Notes/Monthly/${currentYear}-${currentMonth}|Monthly notes]]`;

            return `${previousWeekLink} | ${nextWeekLink} | ${monthlyLink}`;
        }

        get weeklyContent() {
            let content = "";
            for (let i = 0; i < 5; i++) {
                const day = this.monday.clone().add(i, "days");
                const dayFormatted = day.format("YYYY-MM-DD");
                const yearFormatted = day.format("YYYY");
                const monthFormatted = day.format("MM");

                const formattedDayLink = `[[Periodic Notes/Daily/${yearFormatted}/${monthFormatted}/${dayFormatted}|${day.format(
                    "ddd YY.MM.DD"
                )}]]`;

                const highlightsLink = `![[Periodic Notes/Daily/${yearFormatted}/${monthFormatted}/${dayFormatted}${this.highlightsBlock}]]`;

                content += `
> [!daily-highlight]+ ${formattedDayLink}    
> ${highlightsLink}
`;
            }
            return content;
        }
    }

    const {
        weeklyContent,
        startDate,
        friday: endDate,
        navigationLinks,
    } = new WeeklyNote(tp);

    return {
        startDate,
        endDate,
        weeklyContent,
        navigationLinks,
    };
};
