<%*
const { monthlyContent } = await tp.user.monthlyScript();
tR += monthlyContent; 
%>
## 🎯 Monthly Goals

 - 😥 Challenge
 - 🤓 Achievable
 - 🥳 Easy

## 🏆 Ace Recognitions given
[asurion.achievers.com](https://asurion.achievers.com/recent_activity)

## 🏝️ PTO
| Recorded | Date       | Notes | Amt |
| -------- | ---------- | ----- | --- |
|          |            |       |     
## 🔄 Monthly Review

 - 📈 Achievements:
	 - 
 - 📉 To Improve:
	 - 
 - 🗓 Focus for Next Month:
	 - 