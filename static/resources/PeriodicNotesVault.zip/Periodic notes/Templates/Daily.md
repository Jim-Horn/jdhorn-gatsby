---
<%*
const {
    metadata,
    navigation,
    progressBar
} = await tp.user.dailyScript(tp);
%>
tags: <%* tR += metadata.tags %>
weekday: <%* tR += metadata.weekday %>
created: <%* tR += metadata.created %>
---
<%* 
tR += navigation; 
tR += progressBar; 
%>

#### 💭 Daily quote
<% tp.web.daily_quote() %>

#### 🗓️ Calendar

#### 🌟 Highlights
- 

#### 📝 Daily notes & log

#### 🗓️ Meetings

#### 📸 Screenshots

[[Tasks | All Tasks]]

### Today's

```tasks
not done
due date is <%* tR += tp.file.title %>
```

### Completed today
```tasks
done date is <%* tR += tp.file.title %>
```

### Due soon
```tasks
not done
due after in <%* tR += moment(tp.file.title).format('YYYY-MM-DD') %>
due before in <%* tR += moment(tp.file.title).add(1, 'w').format('YYYY-MM-DD') %>
```