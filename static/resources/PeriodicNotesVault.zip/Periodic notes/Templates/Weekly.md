<%*
const {
    weeklyContent,
    startDate,
    endDate,
    navigationLinks
} = await tp.user.weeklyScript(tp);
tR += navigationLinks;
%>
## 🌟 Highlights
<%*
tR += weeklyContent; 
%>



## Weekly Review
 - 📈 Achievements:
 - 📉 To Improve:
 - 🗓 Next Week Focus:

## Pull Requests

## Weekly Goals

## Tasks
### Completed this week
```tasks
done date is between <%* tR += startDate %> and <%* tR += endDate %>
```

### Due this week
```tasks
due date is between <%* tR += startDate %> and <%* tR += endDate %>
```

