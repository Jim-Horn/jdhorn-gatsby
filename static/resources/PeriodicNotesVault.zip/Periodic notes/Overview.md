## What is Obsidian?
[Obsidian](https://obsidian.md/) is a powerful note-taking and knowledge management tool that allows users to create a personal knowledge base using markdown files. It's designed to help you organize and connect your notes through backlinks and graph views, making it easier to visualize and navigate the relationships between your notes.

Here are some key features of Obsidian:

1. **Markdown Support**: Obsidian uses plain text Markdown files, which are easy to read and write, and can be easily edited with any text editor.
2. **Graph View**: This feature provides a visual representation of your notes and how they are linked, helping you to see connections and explore your knowledge base more intuitively.
3. **Backlinks**: Obsidian makes it easy to create and follow backlinks between notes, enabling a networked approach to note-taking.
4. **Plugins and Customization**: Obsidian supports a wide range of plugins that extend its functionality, allowing users to tailor the app to their specific needs.
5. **Local Storage**: Unlike many other note-taking apps that rely on cloud storage, Obsidian stores all your notes locally on your device, giving you full control over your data.

Obsidian is popular among users who need a flexible and powerful tool for managing large amounts of interconnected information, such as researchers, writers, and knowledge workers.
## Why use Obsidian for note keeping?
Using Obsidian for note-keeping offers several advantages due to its unique features and flexibility. Here are some reasons why you might choose Obsidian for managing your notes:

1. **Local First and Privacy**:
   - **Local Storage**: Your notes are stored locally on your device, ensuring you have full control over your data and privacy.
   - **Privacy**: No data is sent to the cloud unless you choose to sync it, reducing the risk of data breaches and unauthorized access.

2. **Markdown Support**:
   - **Plain Text**: Notes are saved in Markdown, a lightweight markup language that's easy to read and write.
   - **Compatibility**: Markdown files are universally compatible with many editors and platforms, ensuring your notes are future-proof.

3. **Linking and Organization**:
   - **Backlinks and Forward Links**: Easily create links between notes, helping you build a network of related ideas.
   - **Graph View**: Visualize the relationships between notes in a graph view, making it easier to see connections and navigate your knowledge base.

4. **Customizability and Plugins**:
   - **Extensibility**: Obsidian has a robust plugin ecosystem, allowing you to add features like task management, calendars, and more.
   - **Themes and CSS**: Customize the look and feel of your notes with themes and custom CSS.

5. **Non-Linear Note Taking**:
   - **Networked Thought**: Obsidian encourages a non-linear approach to note-taking, where notes can be connected in multiple ways, mimicking how human memory works.
   - **Ease of Cross-Referencing**: Quickly reference and link to other notes, enhancing the depth and interconnectedness of your knowledge.

6. **Advanced Features**:
   - **Templates**: Create templates for recurring note structures, saving time and maintaining consistency.
   - **Search and Tagging**: Powerful search and tagging features make it easy to find and organize notes.

7. **Active Community and Support**:
   - **Community Plugins**: A vibrant community develops a wide range of plugins and themes.
   - **Support and Documentation**: Extensive documentation and a helpful community forum provide support and resources for users.

8. **Portability**:
   - **Syncing Options**: While Obsidian primarily stores notes locally, there are options for syncing notes across devices using third-party services like Dropbox, Google Drive, or Obsidian Sync.

Overall, Obsidian is a powerful tool for anyone looking to create a personal knowledge base, manage research, or organize ideas in a highly customizable and interconnected way.
## Community plugins
Community plugins in Obsidian extend the functionality of the core application, allowing users to customize their note-taking experience to suit their needs. These plugins are developed by the community and can be easily installed and managed through Obsidian's settings. Here are a few of the most popular community plugins:

1. **Dataview**:
   - **Description**: Dataview allows you to treat your Markdown files as a database. You can create dynamic views and queries to display data from your notes in tables, lists, and more.
   - **Use Case**: Useful for creating dashboards, summaries, and reports based on the content of your notes.

2. **Kanban**:
   - **Description**: This plugin lets you create Kanban boards within Obsidian, helping you manage tasks and projects visually.
   - **Use Case**: Great for project management, task tracking, and organizing workflows.

3. **Templater**:
   - **Description**: Templater is a powerful template plugin for Obsidian. It allows you to create and use templates for your notes, including advanced scripting capabilities.
   - **Use Case**: Ideal for automating repetitive note structures and enhancing productivity with dynamic templates.

4. **Calendar**:
   - **Description**: The Calendar plugin adds a calendar view to Obsidian, integrating with your daily notes to provide an overview of your notes by date.
   - **Use Case**: Helps in managing daily logs, journals, and date-specific notes.

5. **QuickAdd**:
   - **Description**: QuickAdd allows you to create custom commands for quickly adding content to your notes, such as predefined text snippets, links, or other note templates.
   - **Use Case**: Enhances efficiency by streamlining the process of adding common content to your notes.

6. **Excalidraw**:
   - **Description**: Excalidraw integrates a drawing tool within Obsidian, allowing you to create hand-drawn diagrams and sketches directly in your notes.
   - **Use Case**: Useful for visual thinkers who want to include diagrams, mind maps, or sketches in their notes.

7. **Advanced Tables**:
   - **Description**: This plugin enhances the table editing experience in Obsidian, making it easier to create and manage Markdown tables.
   - **Use Case**: Ideal for users who frequently work with tables and need advanced features for table manipulation.

8. **Tasks**:
   - **Description**: The Tasks plugin adds advanced task management features to Obsidian, allowing you to create, track, and manage tasks within your notes.
   - **Use Case**: Helps in organizing tasks, setting due dates, and tracking progress within your notes.

9. **Periodic Notes**:
   - **Description**: Periodically lets you create notes on a recurring schedule, such as daily, weekly, or monthly notes.
   - **Use Case**: Great for maintaining regular logs, journals, or any content that needs to be updated on a regular basis.

10. **Obsidian Git**:
    - **Description**: This plugin integrates Git version control with Obsidian, enabling you to sync your notes with a Git repository.
    - **Use Case**: Useful for version control, backup, and collaboration, especially for users familiar with Git workflows.

These plugins, along with many others, can significantly enhance your Obsidian experience by adding specialized features and functionalities tailored to your specific needs. The active development and support from the Obsidian community ensure a continuous stream of new and improved plugins.

## Installed plugins
These are the plugins that are core to the periodic notes I keep
- **[Advanced Tables](https://github.com/tgrosinger/advanced-tables-obsidian)**
	- Markdown tables suck. This plugin makes working with them easy! You can quickly add cells, rows, etc. and rearrange them by dragging
- **[Calendar](https://github.com/liamcain/obsidian-calendar-plugin)**
	- Shows a calendar of your periodic notes - and will create new ones on the fly if you click a date that doesn't have one
- **[Outliner](https://github.com/vslinko/obsidian-outliner)**
	- Allows you to rearrange your lists
- **[Paste URL into selection](https://github.com/denolehov/obsidian-url-into-selection)**
	- Adding markdown links to text can be a little cumbersome, but this plugin allows you to select some text and then link that text to a destination
- **[Periodic Notes](https://github.com/liamcain/obsidian-periodic-notes)**
	- The core of our notes
- **[Plugin update tracker](https://github.com/swar8080/obsidian-plugin-update-tracker)**
	- Displays an icon in the status bar, letting you know when updates are available for your installed plugins. To mitigate the risk of installing a broken update, this checks the release date and won't inform you of updates until a few days have passed. (If the plugin update introduced some broken code, hopefully it would be fixed by the time you see an available update)
- **[Tasks](https://github.com/obsidian-tasks-group/obsidian-tasks)**
	- Who needs another task manager? Well, truth is that we probably don't - but this plugin integrates some pretty serious task management into Obsidian
- **[Templater](https://github.com/SilentVoid13/Templater)**
	- Templater is incredibly powerful for automating the creation of pages based on templates you create - and it allows you to script that creation
- **[VSCode Editor](https://github.com/sunxvming/obsidian-vscode-editor)**
	- If you embed code snippets or code files into your notes, this plugin makes editing that code easy

